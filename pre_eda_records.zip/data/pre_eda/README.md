# RDU pre-EDA data package

Data acquisition and preparation are complete. EDA, fitted features/models, forecast scoring and the final project submission remain to be done.

Start with [DATA_DECISIONS.md](DATA_DECISIONS.md): it explains the task, exact hours, each source decision, the history/month tradeoffs, climate and station milestones, validation, metrics and every requirement in plain English. This is a working data memo, not the graded writeup.

Then read [the quality report](reports/QUALITY_REPORT.md) and [the data dictionary](DATA_DICTIONARY.md).

| File/folder | What it is for |
|---|---|
| prepared/initial_eda_training_only_before_2021_cutoff.csv | Starting observation file for EDA that does not expose the later September validation targets. Each subsequent analysis must respect its own training cutoff. |
| prepared/rdu_primary_candidate_2016_to_cutoff.csv | Initial 2026 final-fit candidate, August–October from 2016 onward: 23,208 expected slots, 23,187 provisionally usable temperatures. Do not explore this indiscriminately while treating 2024–2025 targets as untouched confirmation data. |
| prepared/rdu_aug_oct_hourly_2011_to_cutoff.csv | Longer seasonal archive supporting earlier historical tests. |
| prepared/rdu_all_months_hourly_2011_to_cutoff.csv | Continuous history for correct lags and the fair all-months comparison. |
| prepared/historical_validation_plan.csv | Five- and ten-year, three-season candidate splits for five historical September forecasts; no model scores. |
| prepared/target_336_hour_index_and_normals.csv | Exact final output hour index and published-normal lookup; contains no observed final-test temperatures and no fitted final predictions. |
| prepared/gfs_20260916_18Z_target_forecast_inputs.csv | Pre-cutoff model forecast input covering the complete target window; not actual future weather. |
| prepared/gfs_2026_historical_fixed_run_forecasts.csv | Shorter, separate 2026 explicit-run archive for later forecast calibration tests. |
| prepared/noaa_hourly_temperature_normals_local_standard_time.csv | Published hourly normal values in their original standard-time convention. |
| raw/ | Unchanged source downloads: 16 IEM local-year files, 15 NOAA UTC-year files, climate normals and 23 GFS runs. NOAA station/year products arrive with more report types/fields than the preparation uses; these do not increase the model's training sample. |
| metadata/ | Station history, identifiers, exact source URLs, source hashes, GFS availability evidence and the data contract. |
| reports/ | Missing-hour, duplicate/report-selection, quality, coverage and source-comparison audits. |
| reproducibility/ | Download/preparation scripts and dependency record; no EDA or forecasting model code. |

Two explicit limitations remain: the instructor's exact hourly measurement/unit definition is not provided, and the three seasonal source disagreements are preserved for review before scoring. These are not silently resolved by interpolation or by changing the test window. The 2026 station readings were checked locally but were not crosschecked against a whole-year NOAA 2026 file, which would also contain the final test actuals. See the quality report for full detail.

Use `temperature_usable_f` for the provisional screened label, and retain `temperature_f`/METAR/NOAA alternatives for quality review. Blank targets are not zero. Future observed humidity, rain, clouds, wind, pressure and temperature remain forbidden inputs even if they are present in historical training rows. Fit preprocessing and construct origin-known features within each historical fold, after EDA.
