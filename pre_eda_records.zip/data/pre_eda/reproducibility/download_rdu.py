from pathlib import Path
import urllib.request, urllib.parse, json, hashlib, datetime, time
from zoneinfo import ZoneInfo

BASE=Path(__file__).resolve().parents[1]
NY=ZoneInfo('America/New_York')
FIELDS=['tmpf','dwpf','relh','drct','sknt','mslp','p01i','skyc1','skyc2','skyc3','metar']
manifest=[]
def fetch(url,path):
    dest=BASE/path
    if dest.exists():
        body=dest.read_bytes()
    else:
        for attempt in range(3):
            try:
                with urllib.request.urlopen(url,timeout=120) as response:
                    body=response.read()
                if not body or body.startswith(b'<html'): raise ValueError('Empty or HTML response')
                dest.parent.mkdir(parents=True,exist_ok=True)
                dest.write_bytes(body)
                break
            except Exception:
                if attempt==2: raise
                time.sleep(3*(attempt+1))
    manifest.append(dict(file=path,url=url,bytes=len(body),sha256=hashlib.sha256(body).hexdigest(),retrieved_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
    (BASE/'metadata/download_manifest.json').write_text(json.dumps(manifest,indent=2))
    print(path,len(body),flush=True)
    return body

for year in range(2011,2027):
    start=datetime.datetime(year,1,1,tzinfo=NY).astimezone(datetime.timezone.utc)
    end=datetime.datetime(year+1,1,1,tzinfo=NY).astimezone(datetime.timezone.utc) if year<2026 else datetime.datetime(2026,9,17,tzinfo=NY).astimezone(datetime.timezone.utc)
    p=[('station','RDU'),('network','NC_ASOS'),('sts',start.isoformat()),('ets',end.isoformat()),('tz','UTC'),('format','onlycomma'),('missing','M'),('trace','T'),('direct','yes'),('report_type','3')]+[('data',v) for v in FIELDS]
    url='https://mesonet.agron.iastate.edu/cgi-bin/request/asos.py?'+urllib.parse.urlencode(p)
    fetch(url,f'raw/iem_rdu_{year}_routine_utc.csv')
    time.sleep(1.1)

optional=[
('https://mesonet.agron.iastate.edu/geojson/network/NC_ASOS.geojson','metadata/iem_nc_asos_network.geojson'),
('https://www.ncei.noaa.gov/data/normals-hourly/1991-2020/access/USW00013722.csv','raw/noaa_rdu_hourly_normals_1991_2020.csv'),
('https://www.ncei.noaa.gov/oa/global-historical-climatology-network/hourly/access/by-year/2025/psv/GHCNh_USW00013722_2025.psv','raw/noaa_ghcnh_rdu_2025.psv'),
('https://www.ncei.noaa.gov/access/homr/services/station/search?qid=WBAN:13722&date=all','metadata/noaa_homr_rdu.json'),
]
fail=[]
for url,path in optional:
    try: fetch(url,path)
    except Exception as e:
        fail.append(dict(url=url,file=path,error=str(e))); print('FAILED',path,str(e),flush=True)
(BASE/'metadata/download_failures.json').write_text(json.dumps(fail,indent=2))
