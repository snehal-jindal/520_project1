from pathlib import Path
import urllib.request,urllib.parse,json,hashlib,datetime,time
BASE=Path(__file__).resolve().parents[1]
FIELDS='temperature_2m,dew_point_2m,relative_humidity_2m,cloud_cover,pressure_msl,precipitation,wind_speed_10m,wind_direction_10m'
manifest=[]
date=datetime.date(2026,4,2)
runs=[]
while date<=datetime.date(2026,8,27):
    runs.append(date.isoformat()+'T18:00'); date+=datetime.timedelta(days=7)
runs.append('2026-09-16T18:00')
for run in runs:
    params=dict(latitude=35.8922,longitude=-78.7819,hourly=FIELDS,models='gfs_global',run=run,forecast_days=16,timezone='UTC',temperature_unit='fahrenheit',wind_speed_unit='ms',precipitation_unit='mm')
    url='https://single-runs-api.open-meteo.com/v1/forecast?'+urllib.parse.urlencode(params)
    fn='raw/gfs_single_runs/gfs_'+run.replace('-','').replace(':','')+'Z.json'
    path=BASE/fn
    try:
        if path.exists(): body=path.read_bytes()
        else:
            for attempt in range(3):
                try:
                    with urllib.request.urlopen(url,timeout=60) as r: body=r.read()
                    j=json.loads(body)
                    assert 'hourly' in j, j
                    path.parent.mkdir(parents=True,exist_ok=True); path.write_bytes(body)
                    break
                except Exception:
                    if attempt==2: raise
                    time.sleep(2)
        manifest.append(dict(file=fn,url=url,run_utc=run+'Z',sha256=hashlib.sha256(body).hexdigest(),bytes=len(body),retrieved_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
        print(run,'downloaded',flush=True)
    except Exception as e:
        manifest.append(dict(run_utc=run+'Z',url=url,error=str(e))); print(run,str(e),flush=True)
    (BASE/'metadata/gfs_download_manifest.json').write_text(json.dumps(manifest,indent=2))
    time.sleep(.5)
headers=[]
for lead in (0,120,240,345,384):
    u=f'https://noaa-gfs-bdp-pds.s3.amazonaws.com/gfs.20260916/18/atmos/gfs.t18z.pgrb2.0p25.f{lead:03d}.idx'
    try:
        with urllib.request.urlopen(urllib.request.Request(u,method='HEAD'),timeout=25) as r:
            headers.append(dict(url=u,status=r.status,last_modified=r.headers.get('Last-Modified'),etag=r.headers.get('ETag')))
    except Exception as e: headers.append(dict(url=u,error=str(e)))
(BASE/'metadata/gfs_publication_headers.json').write_text(json.dumps(headers,indent=2))
