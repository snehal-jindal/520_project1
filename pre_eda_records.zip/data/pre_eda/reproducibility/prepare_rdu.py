from pathlib import Path
import pandas as pd,numpy as np,json,re,datetime,hashlib,zipfile

B=Path(__file__).resolve().parents[1]
NY='America/New_York'
START=pd.Timestamp('2011-01-01',tz=NY).tz_convert('UTC')
CUTOFF=pd.Timestamp('2026-09-17',tz=NY).tz_convert('UTC')
NUM={'tmpf':'temperature_f','dwpf':'dew_point_f','relh':'relative_humidity_pct','drct':'wind_direction_deg','sknt':'wind_speed_knots','mslp':'sea_level_pressure_hpa','p01i':'precipitation_1h_inches'}
def save(df,path):
    out=df.copy()
    for col in out:
        if isinstance(out[col].dtype,pd.DatetimeTZDtype):
            out[col]=out[col].map(lambda x:x.isoformat() if pd.notna(x) else '')
    out.to_csv(B/path,index=False,float_format='%.5f')
def writejson(obj,path): (B/path).write_text(json.dumps(obj,indent=2,default=str))

parts=[]
for p in sorted((B/'raw').glob('iem_rdu_*_routine_utc.csv')):
    d=pd.read_csv(p,dtype=str,keep_default_na=False)
    assert set(d.columns)==set(['station','valid','skyc1','skyc2','skyc3','metar']+list(NUM)),p
    d['source_file']=p.name;d['source_row']=np.arange(2,len(d)+2);parts.append(d)
d=pd.concat(parts,ignore_index=True)
d['observation_time_utc']=pd.to_datetime(d.valid,utc=True,errors='raise')
assert d.station.eq('RDU').all()
assert d.observation_time_utc.between(START,CUTOFF,inclusive='left').all()
d['hour_label_utc']=d.observation_time_utc.dt.floor('h')
d['minutes_after_hour']=d.observation_time_utc.dt.minute
d['distance_from_routine_minute']=abs(d.minutes_after_hour-51)
for k,v in NUM.items(): d[v]=pd.to_numeric(d[k].replace({'M':None,'T':None,'' :None}),errors='raise')
d['precipitation_trace']=d.p01i.eq('T')
d['variable_wind']=d.metar.str.contains(r'\bVRB\d{2}(?:G\d{2})?KT\b',regex=True)
d['metar_temperature_c']=d.metar.str.extract(r'\bT([01]\d{3})[01]\d{3}\b')[0].map(lambda s:float(s[1:])/10*(-1 if s[0]=='1' else 1) if pd.notna(s) else np.nan)
d['metar_temperature_f']=d.metar_temperature_c*1.8+32
for c in ['skyc1','skyc2','skyc3']: d[c]=d[c].replace({'M':None,'':None})
d['temperature_missing']=d.temperature_f.isna()
original=len(d)
exact=int(d.drop(columns=['source_file','source_row']).duplicated().sum())
# Fixed selection rule, independent of temperature magnitude: expected reporting minute,
# then observed target availability, then stable source order. Keep every alternative.
d=d.sort_values(['hour_label_utc','distance_from_routine_minute','temperature_missing','observation_time_utc','source_file','source_row'],kind='stable')
d['selected_for_hour']=~d.hour_label_utc.duplicated()
multi=d.hour_label_utc.duplicated(keep=False)
save(d.loc[multi,['hour_label_utc','observation_time_utc','tmpf','metar','source_file','source_row','selected_for_hour']], 'reports/multiple_reports_per_hour.csv')
chosen=d.loc[d.selected_for_hour].copy()
cols=['hour_label_utc','observation_time_utc','station']+list(NUM.values())+['precipitation_trace','variable_wind','skyc1','skyc2','skyc3','metar','metar_temperature_c','metar_temperature_f','source_file','source_row','minutes_after_hour']
idx=pd.date_range(START,CUTOFF,freq='h',inclusive='left')
full=chosen[cols].set_index('hour_label_utc').reindex(idx).rename_axis('hour_label_utc').reset_index()
full['hour_label_local']=full.hour_label_utc.dt.tz_convert(NY)
full['observation_time_local']=full.observation_time_utc.dt.tz_convert(NY)
full['station']='RDU'
full['report_present']=full.observation_time_utc.notna()
full['temperature_missing']=full.temperature_f.isna()
full['year']=full.hour_label_local.dt.year
full['month']=full.hour_label_local.dt.month
full['primary_season']=full.month.between(8,10)
full['candidate_final_training']=full.primary_season & full.year.ge(2016)
full['archive_role']=np.where(full.year.lt(2016),'historical_backtest_support','recent_history')
full['temperature_c']=(full.temperature_f-32)/1.8
full['dew_point_c']=(full.dew_point_f-32)/1.8
full['wind_speed_ms']=full.wind_speed_knots*0.514444444444
full['precipitation_1h_mm']=full.precipitation_1h_inches*25.4
for c in ['precipitation_trace','variable_wind']: full[c]=full[c].astype('boolean').fillna(False).astype(bool)
season=full.loc[full.primary_season].copy()
assert len(full)==137711 and len(season)==34248 and full.hour_label_utc.is_unique
save(full,'prepared/rdu_all_months_hourly_2011_to_cutoff.csv')
save(season,'prepared/rdu_aug_oct_hourly_2011_to_cutoff.csv')
save(season.loc[season.candidate_final_training],'prepared/rdu_primary_candidate_2016_to_cutoff.csv')
save(full.loc[full.temperature_missing,['hour_label_utc','hour_label_local','observation_time_utc','year','month','primary_season','report_present']], 'reports/missing_temperature_hours.csv')
save(full.loc[full.report_present & full.minutes_after_hour.ne(51),['hour_label_utc','observation_time_utc','minutes_after_hour','source_file','source_row']], 'reports/off_schedule_reports.csv')
coverage=[]
for view,table in [('all_months',full),('aug_oct',season),('primary_2016_onward',season.loc[season.candidate_final_training])]:
    for y,g in table.groupby('year'):
        coverage.append(dict(view=view,year=int(y),expected_hours=len(g),reports_present=int(g.report_present.sum()),usable_temperature_hours=int(g.temperature_f.notna().sum()),missing_temperature_hours=int(g.temperature_missing.sum()),temperature_coverage_pct=round(100*g.temperature_f.notna().mean(),4)))
save(pd.DataFrame(coverage),'reports/coverage_by_year.csv')
missing=[]
for view,table in [('all_months',full),('aug_oct',season),('primary_2016_onward',season.loc[season.candidate_final_training])]:
    for c in list(NUM.values())+['skyc1','skyc2','skyc3','metar_temperature_c']:
        missing.append(dict(view=view,column=c,total_hours=len(table),missing_hours=int(table[c].isna().sum()),note='Missing additional cloud layer can mean no such layer; not automatically a sensor failure.' if c in ['skyc2','skyc3'] else 'Trace precipitation remains nonnumeric, with a separate trace flag.' if c=='precipitation_1h_inches' else ''))
save(pd.DataFrame(missing),'reports/field_completeness.csv')
flags=[]
for name,mask in [
    ('temperature_outside_broad_physical_bounds',full.temperature_f.lt(-130)|full.temperature_f.gt(140)),
    ('humidity_outside_0_100',full.relative_humidity_pct.lt(0)|full.relative_humidity_pct.gt(100)),
    ('negative_wind_speed',full.wind_speed_knots.lt(0)),
    ('wind_direction_outside_0_360',full.wind_direction_deg.lt(0)|full.wind_direction_deg.gt(360)),
    ('negative_precipitation',full.precipitation_1h_inches.lt(0)),
    ('dew_point_exceeds_temperature_by_over_2F',full.dew_point_f.gt(full.temperature_f+2)),
]:
    z=full.loc[mask,['hour_label_utc','observation_time_utc']+list(NUM.values())].copy();z['flag']=name; flags.append(z)
save(pd.concat(flags,ignore_index=True),'reports/physical_consistency_flags.csv')

# Independent archive check, matching exact timestamps rather than rounding all reports.
n=pd.concat([pd.read_csv(p,sep='|',dtype=str,keep_default_na=False,usecols=['STATION','DATE','temperature','temperature_Quality_Code','temperature_Report_Type','temperature_Source_Code']) for p in sorted((B/'raw').glob('noaa_ghcnh_rdu_*.psv'))],ignore_index=True)
assert n.STATION.eq('USW00013722').all()
n['observation_time_utc']=pd.to_datetime(n.DATE,utc=True)
n['noaa_temperature_c']=pd.to_numeric(n.temperature.replace('',None),errors='raise')
n['noaa_temperature_f']=n.noaa_temperature_c*1.8+32
cross=chosen[['observation_time_utc','temperature_f','metar_temperature_f']].merge(n[['observation_time_utc','noaa_temperature_c','noaa_temperature_f','temperature_Quality_Code','temperature_Report_Type','temperature_Source_Code']],on='observation_time_utc',how='left',validate='one_to_one')
cross['difference_f']=cross.temperature_f-cross.noaa_temperature_f
cross['precision_difference_f']=cross.metar_temperature_f-cross.noaa_temperature_f
legacy=cross.temperature_Source_Code.isin(['313','314','315','322','335','343','344','346'])
synop=cross.temperature_Source_Code.isin(['220','221','222','223','347','348'])
cross['source_quality_failure']=(legacy&cross.temperature_Quality_Code.isin(['2','3','6','7']))|(synop&cross.temperature_Quality_Code.isin(['2','3','5']))|cross.temperature_Quality_Code.fillna('').str.contains('[a-z]')
cross['whole_celsius_precision_consistent']=cross.metar_temperature_f.isna()&cross.difference_f.abs().le(.901)
cross['source_temperature_disagreement']=cross.difference_f.abs().gt(.6)&~cross.whole_celsius_precision_consistent
cross['requires_review']=cross.source_temperature_disagreement|cross.source_quality_failure
save(cross,'reports/noaa_2011_2025_exact_timestamp_crosscheck.csv')
save(cross.loc[cross.requires_review],'reports/noaa_2011_2025_discrepancies.csv')
review_times=set(cross.loc[cross.requires_review,'observation_time_utc'])
full['temperature_archive_review_flag']=full.observation_time_utc.isin(review_times)
full['temperature_usable_f']=full.temperature_f.mask(full.temperature_archive_review_flag)
full['temperature_usable_c']=(full.temperature_usable_f-32)/1.8
qcmap=cross.set_index('observation_time_utc')['temperature_Quality_Code']
full['noaa_temperature_quality_code']=full.observation_time_utc.map(qcmap)
full['noaa_temperature_crosscheck_present']=full.observation_time_utc.isin(set(cross.loc[cross.noaa_temperature_f.notna(),'observation_time_utc']))
season=full.loc[full.primary_season].copy()
save(full,'prepared/rdu_all_months_hourly_2011_to_cutoff.csv')
save(season,'prepared/rdu_aug_oct_hourly_2011_to_cutoff.csv')
save(season.loc[season.candidate_final_training],'prepared/rdu_primary_candidate_2016_to_cutoff.csv')
quality=[]
for view,table in [('all_months',full),('aug_oct',season),('primary_2016_onward',season.loc[season.candidate_final_training])]:
    for y,g in table.groupby('year'):
        quality.append(dict(view=view,year=int(y),expected_hours=len(g),raw_missing_temperature_hours=int(g.temperature_missing.sum()),quarantined_temperature_hours=int(g.temperature_archive_review_flag.sum()),usable_temperature_hours=int(g.temperature_usable_f.notna().sum()),usable_temperature_coverage_pct=round(100*g.temperature_usable_f.notna().mean(),4)))
save(pd.DataFrame(quality),'reports/coverage_after_quality_screening.csv')
save(season.loc[season.observation_time_utc.lt(pd.Timestamp('2021-09-17',tz=NY).tz_convert('UTC'))],'prepared/initial_eda_training_only_before_2021_cutoff.csv')

# Normals are a published climatological benchmark, not new observations or fitted predictions.
normal=pd.read_csv(B/'raw/noaa_rdu_hourly_normals_1991_2020.csv',dtype=str,keep_default_na=False)
assert normal.STATION.eq('USW00013722').all()
normal['normal_temperature_f']=pd.to_numeric(normal['HLY-TEMP-NORMAL'].str.strip().replace('-9999',None),errors='raise')
normal['key']=normal.DATE.str.strip()
normcols=['month','day','hour','normal_temperature_f','comp_flag_HLY-TEMP-NORMAL','years_HLY-TEMP-NORMAL']
save(normal[normcols], 'prepared/noaa_hourly_temperature_normals_local_standard_time.csv')
target=pd.DataFrame({'hour_label_utc':pd.date_range(CUTOFF,periods=336,freq='h')})
target['hour_label_local']=target.hour_label_utc.dt.tz_convert(NY)
target['forecast_slot']=np.arange(1,337)
target['hours_from_cutoff']=np.arange(336)
target['forecast_day']=np.arange(336)//24+1
target['normal_lookup_local_standard_time']=target.hour_label_utc.dt.tz_convert(datetime.timezone(datetime.timedelta(hours=-5))).dt.strftime('%m-%dT%H:%M:%S')
target=target.merge(normal[['key','normal_temperature_f']],left_on='normal_lookup_local_standard_time',right_on='key',how='left',validate='many_to_one').drop(columns='key')
assert target.normal_temperature_f.notna().all()
assert target.hour_label_local.iloc[-1]==pd.Timestamp('2026-09-30T23:00',tz=NY)
save(target,'prepared/target_336_hour_index_and_normals.csv')

folds=[]
for y in range(2021,2026):
    origin=pd.Timestamp(f'{y}-09-17',tz=NY).tz_convert('UTC')
    test=full.loc[full.hour_label_utc.ge(origin)&full.hour_label_utc.lt(origin+pd.Timedelta(hours=336))]
    for years in [5,10]:
        start=pd.Timestamp(f'{y-years}-01-01',tz=NY).tz_convert('UTC')
        for seasonname,condition in [('september',full.month.eq(9)),('aug_oct',full.primary_season),('all_months',pd.Series(True,index=full.index))]:
            train=full.loc[full.observation_time_utc.ge(start)&full.observation_time_utc.lt(origin)&condition]
            folds.append(dict(test_year=y,role='development' if y<=2023 else 'locked_confirmation',forecast_origin_utc=origin,forecast_origin_local=origin.tz_convert(NY),test_start_utc=origin,test_end_exclusive_utc=origin+pd.Timedelta(hours=336),training_start_local=f'{y-years}-01-01T00:00:00',history_complete_prior_years=years,season=seasonname,train_observed_temperature_rows=int(train.temperature_usable_f.notna().sum()),test_expected_hours=336,test_observed_temperature_hours=int(test.temperature_usable_f.notna().sum()),eligible_for_1991_2020_normals_benchmark=True))
save(pd.DataFrame(folds),'prepared/historical_validation_plan.csv')

forecasts=[]
for p in sorted((B/'raw/gfs_single_runs').glob('gfs_*.json')):
    j=json.loads(p.read_text());run=pd.to_datetime(p.stem.removeprefix('gfs_'),format='%Y%m%dT%H%MZ',utc=True)
    f=pd.DataFrame(j['hourly']);f['valid_time_utc']=pd.to_datetime(f.pop('time'),utc=True)
    origin=run.normalize()+pd.Timedelta(days=1,hours=4)
    f=f.loc[f.valid_time_utc.ge(origin)&f.valid_time_utc.lt(origin+pd.Timedelta(hours=336))].copy()
    assert len(f)==336 and f.temperature_2m.notna().all(),p
    f['model_initialization_utc']=run; f['forecast_origin_utc']=origin
    f['lead_hours_from_model_initialization']=(f.valid_time_utc-run).dt.total_seconds()/3600
    f['hours_from_forecast_origin']=(f.valid_time_utc-origin).dt.total_seconds()/3600
    f['valid_time_local']=f.valid_time_utc.dt.tz_convert(NY)
    f['role']='final_forecast_input' if run==pd.Timestamp('2026-09-16T18:00Z') else 'historical_2026_calibration_candidate'
    f['source_file']=p.name;f['grid_latitude']=j['latitude'];f['grid_longitude']=j['longitude'];f['api_elevation_m']=j['elevation']
    f['native_temporal_resolution_hours']=np.where(f.lead_hours_from_model_initialization.gt(120),3,1)
    f['api_hourly_interpolation_after_120h']=f.lead_hours_from_model_initialization.gt(120)
    forecasts.append(f)
gfs=pd.concat(forecasts,ignore_index=True)
save(gfs.loc[gfs.role.eq('final_forecast_input')],'prepared/gfs_20260916_18Z_target_forecast_inputs.csv')
save(gfs.loc[gfs.role.ne('final_forecast_input')],'prepared/gfs_2026_historical_fixed_run_forecasts.csv')

# Station history: preserve full metadata; summarize only actual descriptions, no inferred moves.
homr=json.loads((B/'metadata/noaa_homr_rdu.json').read_text())['stationCollection']['stations'][0]
station=json.loads((B/'metadata/iem_nc_asos_network.geojson').read_text())
writejson(next(x for x in station['features'] if x['id']=='RDU'),'metadata/iem_rdu_station.json')
writejson({'ncdc_id':homr['ncdcStnId'],'identifiers':homr['identifiers'],'platforms':homr['platforms'],'location':homr['location'],'remarks':homr['remarks'],'temperature_equipment_entries':[e for e in homr['elements'] if e.get('element')=='TEMP']},'metadata/rdu_station_history_summary.json')
summary={
    'cutoff_utc_exclusive':str(CUTOFF),'first_observation_utc':str(d.observation_time_utc.min()),'last_observation_utc':str(d.observation_time_utc.max()),
    'raw_observation_rows':original,'exact_duplicate_rows':exact,'duplicate_observation_timestamps':int(d.observation_time_utc.duplicated().sum()),'hours_with_multiple_routine_reports':int(d.loc[multi,'hour_label_utc'].nunique()),
    'all_months_expected_hours':len(full),'all_months_present_reports':int(full.report_present.sum()),'all_months_missing_temperature_hours':int(full.temperature_missing.sum()),
    'seasonal_expected_hours':len(season),'seasonal_usable_temperature_hours':int(season.temperature_f.notna().sum()),'seasonal_missing_temperature_hours':int(season.temperature_missing.sum()),
    'primary_2016_onward_expected_hours':int(season.candidate_final_training.sum()),'primary_2016_onward_missing_temperature_hours':int(season.loc[season.candidate_final_training,'temperature_missing'].sum()),
    'off_schedule_selected_reports':int((full.report_present&full.minutes_after_hour.ne(51)).sum()),'physical_consistency_flag_rows':sum(len(x) for x in flags),
    'noaa_crosscheck_matched_temperature_rows':int(cross.noaa_temperature_f.notna().sum()),'noaa_crosscheck_review_rows':int(cross.requires_review.sum()),
    'all_months_quarantined_temperature_hours':int(full.temperature_archive_review_flag.sum()),'seasonal_quarantined_temperature_hours':int(season.temperature_archive_review_flag.sum()),'primary_2016_onward_quarantined_temperature_hours':int(season.loc[season.candidate_final_training,'temperature_archive_review_flag'].sum()),'primary_2016_onward_quality_screened_temperature_hours':int(season.loc[season.candidate_final_training,'temperature_usable_f'].notna().sum()),
    'gfs_runs_downloaded':len(forecasts),'gfs_historical_14day_rows':int(gfs.role.ne('final_forecast_input').sum()),'gfs_final_14day_rows':int(gfs.role.eq('final_forecast_input').sum()),
    'target_hours':len(target),'target_observations_downloaded':False,'temperature_imputation_performed':False,'eda_performed':False,'models_fitted':False,
}
writejson(summary,'reports/preparation_summary.json')
print(json.dumps(summary,indent=2))
