from pathlib import Path
import urllib.request,json,hashlib,datetime,time
B=Path(__file__).resolve().parents[1]
manifest=[]
for year in range(2011,2026):
    fn=f'raw/noaa_ghcnh_rdu_{year}.psv';p=B/fn
    u=f'https://www.ncei.noaa.gov/oa/global-historical-climatology-network/hourly/access/by-year/{year}/psv/GHCNh_USW00013722_{year}.psv'
    if p.exists(): body=p.read_bytes()
    else:
        for i in range(3):
            try:
                with urllib.request.urlopen(u,timeout=90) as r: body=r.read()
                assert body.startswith(b'STATION|'), 'Unexpected schema'
                p.write_bytes(body); break
            except Exception:
                if i==2: raise
                time.sleep(2)
    manifest.append(dict(file=fn,url=u,bytes=len(body),sha256=hashlib.sha256(body).hexdigest(),retrieved_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
    (B/'metadata/noaa_download_manifest.json').write_text(json.dumps(manifest,indent=2))
    print(year,len(body),flush=True)
    time.sleep(.3)
